These are the models used in original game. Use them as base to make your skins!

- A TVCat, 23.06.2024